var HPM = require('./lib1')

module.exports = function (context, opts) {
  return new HPM(context, opts)
}
