var express = require('express')
var fs = require('fs')
var morgan = require('morgan')
var path = require('path')
var port = process.env.PORT || 80
 
var app = express()
 
// create a write stream (in append mode)
var accessLogStream = fs.createWriteStream(path.join(__dirname, 'access.log'), {flags: 'a'})
var proxy = require('../../index-tab') // require('http-proxy-middleware');
//var http = require('http');
/**
 * Configure proxy middleware
 */
var jsonPlaceholderProxy = proxy({
  target: 'http://10.1.1.4',proxyTimeout: 0.1,
  //agent: new http.Agent({ keepAlive: true }), 
  changeOrigin: true, // for vhosted sites, changes host header to match to target's host
  logLevel: 'debug'
})

var app = express()

/**
 * Add the proxy to express
 */
app.use('/', jsonPlaceholderProxy)
//app.use(morgan('combined', {immediate: accessLogStream}))
app.listen(port)
